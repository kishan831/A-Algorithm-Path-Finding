[System.Serializable]
public class Path
{
    public Tile[] tiles;
}
