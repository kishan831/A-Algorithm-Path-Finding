# A-Star-pathfinding
 
![alt text](https://github.com/ForlornU/Images/blob/main/pic2.png)

A* pathfinding for use across hexagonal tiles in the unity3d engine!

This is an entire unity3d project, you can start this in the unity editor and play around in the scene 
or if you just want to use some small part of it that's fine too, I hope in can help you in some way!

This is a continuation of my BreadthFirstSearch project where I replaced the BFS with A* as well as some other improvements such as camera movement and changing costs at runtime, I'm hoping to explore this further and add different types of pathfinding algorithms later on and present them in small, easy to use versions

Link to video:
https://youtu.be/i013l1hDoIc


